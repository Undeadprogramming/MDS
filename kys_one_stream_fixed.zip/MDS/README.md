# MDS – 1 stream (Publisher → FFmpeg → HLS → Viewer)

Tahle verze projektu je zjednodušená na **jeden aktivní stream**.

- **Publisher (prohlížeč)**: vezme kameru+mikrofon a přes **MediaRecorder** posílá binární **WebM chunky** přes WebSocket.
- **Node server**: přijímá chunky na `wss://localhost/ws`, pouští **FFmpeg** a generuje **HLS** playlisty do `nginx/site/hls/`.
- **Nginx**: servíruje web (`/`, `/publish.html`) a HLS (`/hls/...`) přes HTTPS + proxy pro `/api/*` a `/ws`.

> Pozn.: WebRTC (`wrtc`) se nepoužívá – problém s instalací nativního modulu tím odpadá.

---

## Požadavky

- **Windows** (projekt je připravený hlavně pro Windows)
- **Node.js 20 LTS** (doporučeno) + npm
- **FFmpeg** v PATH (aby příkaz `ffmpeg` fungoval v terminálu)
- **Chrome / Edge** (kvůli `MediaRecorder` do WebM)

FFmpeg (příklad): build od GyanD (zip) → rozbalit → přidat `bin` do PATH.

---

## Spuštění

### 1) Node server (WS + API + FFmpeg)

V PowerShellu:

```powershell
cd MDS\server

# Doporučení: čistá instalace (hlavně pokud jsi dřív zkoušel wrtc)
rmdir /s /q node_modules
del package-lock.json

npm install
npm start
```

Node běží na: `http://127.0.0.1:3000`
- WS: `ws(s)://localhost/ws`
- API: `/api/presenters`, `/api/status`

### 2) Nginx (HTTPS + statické soubory + proxy)

V druhém PowerShellu:

```powershell
cd MDS\nginx

# pokud už nginx běžel
.\kill-nginx.bat

# volitelné: ověř konfiguraci
.\test-config.bat

# start
.\NGINX.exe
```

> Nginx poslouchá na **443** (HTTPS). Na některých Windows konfiguracích může být potřeba spustit terminál jako **Administrator**.

---

## Použití

### Publisher
1. Otevři: `https://localhost/publish.html`
2. Klikni **Zapnout náhled**
3. Vyplň **Tvoje jméno**
4. Vyplň **Publikační klíč**
   - default: `mds2025` (v `MDS/server/server.js` jako `PUBLISH_KEY`)
5. Klikni **Start publikování**

> Aktuálně je podporovaný **jen jeden publisher** (1 stream). Druhý se odmítne.

### Viewer
- Otevři: `https://localhost/`
- Jakmile se vytvoří `https://localhost/hls/master.m3u8`, přehrávač se spustí automaticky.

> Při prvním otevření HTTPS pravděpodobně vyskočí varování o certifikátu (self-signed). Je potřeba ho v prohlížeči potvrdit.

---

## Kde hledat, že to fakt běží

- Node konzole po `Start publikování` vypíše `publish_start ...`
- Vzniknou soubory v:
  - `MDS/nginx/site/hls/master.m3u8`
  - `MDS/nginx/site/hls/v0/prog_index.m3u8` + `seg_*.ts`

---

## Troubleshooting

### Viewer nic nehraje
1) Otevři v prohlížeči přímo:
- `https://localhost/hls/master.m3u8`

Když je to **404**, tak se HLS negeneruje.

2) Zkontroluj, jestli FFmpeg existuje:
```powershell
ffmpeg -version
```

3) Koukní do konzole, kde běží `node server.js` – když FFmpeg spadne, uvidíš to tam.

### Publish stránka po kliknutí Start nic nepřijme zpět
- V logu publish stránky musí být `WS <= {"type":"publish_ok",...}`.
- Pokud ne, zkontroluj `key` (publikační klíč) a Node konzoli.

### Prohlížeč nepodporuje WebM recorder
- Použij Chrome / Edge.

---

## Ukončení

- Node: `Ctrl + C`
- Nginx:
```powershell
cd MDS\nginx
.\stop-nginx.bat
```
