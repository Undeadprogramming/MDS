"use strict";

const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const { spawn } = require("child_process");
const path = require("path");
const fs = require("fs");

const PORT = process.env.PORT || 3000;
const PUBLISH_KEY = process.env.PUBLISH_KEY || "mds2025";

// HLS jde do nginx/site/hls (u tebe už existuje)
const HLS_DIR = path.resolve(__dirname, "../nginx/site/hls");

function ensureDir(p) {
  fs.mkdirSync(p, { recursive: true });
}

function emptyDir(dir) {
  if (!fs.existsSync(dir)) return;
  for (const entry of fs.readdirSync(dir)) {
    fs.rmSync(path.join(dir, entry), { recursive: true, force: true });
  }
}

function send(ws, obj) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}

function startFfmpegWebmToHls(hlsDir) {
  ensureDir(hlsDir);
  emptyDir(hlsDir);
  ensureDir(path.join(hlsDir, "v0"));
  ensureDir(path.join(hlsDir, "v1"));
  ensureDir(path.join(hlsDir, "v2"));

  const args = [
    "-hide_banner",
    "-loglevel",
    "warning",
    "-fflags",
    "+genpts",
    "-i",
    "pipe:0",

    "-filter_complex",
    [
      "[0:v]split=3[v720][v480][v360]",
      "[v720]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2[v0]",
      "[v480]scale=854:480:force_original_aspect_ratio=decrease,pad=854:480:(ow-iw)/2:(oh-ih)/2[v1]",
      "[v360]scale=640:360:force_original_aspect_ratio=decrease,pad=640:360:(ow-iw)/2:(oh-ih)/2[v2]",
    ].join(";"),

    "-map",
    "[v0]",
    "-map",
    "0:a?",
    "-map",
    "[v1]",
    "-map",
    "0:a?",
    "-map",
    "[v2]",
    "-map",
    "0:a?",

    "-c:v",
    "libx264",
    "-preset",
    "ultrafast",
    "-tune",
    "zerolatency",
    "-profile:v",
    "main",
    "-pix_fmt",
    "yuv420p",

    "-g",
    "60",
    "-keyint_min",
    "60",
    "-sc_threshold",
    "0",

    "-c:a",
    "aac",
    "-b:a",
    "128k",
    "-ac",
    "2",
    "-ar",
    "48000",

    "-f",
    "hls",
    "-hls_time",
    "4",
    "-hls_list_size",
    "200",
    "-hls_flags",
    "independent_segments+delete_segments+append_list",
    "-hls_segment_filename",
    "v%v/seg_%05d.ts",
    "-master_pl_name",
    "master.m3u8",
    "-var_stream_map",
    "v:0,a:0 v:1,a:1 v:2,a:2",
    "v%v/prog_index.m3u8",
  ];

  const ff = spawn("ffmpeg", args, {
    cwd: hlsDir,
    stdio: ["pipe", "inherit", "inherit"], // stdin = webm chunky
  });

  return ff;
}

// ===== Express API (zůstává kompatibilní s nginx /api/) =====
const app = express();
app.use(express.json());

app.get("/api/status", (_req, res) => {
  res.json({
    ok: true,
    time: new Date().toISOString(),
    streaming: !!ffmpegProc,
    presenter: currentPresenter
      ? { id: currentPresenter.id, name: currentPresenter.name, muted: currentPresenter.muted }
      : null,
  });
});

const server = http.createServer(app);

// WS na /ws (tohle nginx proxyuje)
const wss = new WebSocket.Server({ server, path: "/ws" });

// všichni WS klienti (publisher + viewer)
const clients = new Set();

// ===== 1 stream stav =====
let publisherWs = null;
let ffmpegProc = null;
let currentPresenter = null;

function presentersList() {
  return currentPresenter
    ? [{ id: currentPresenter.id, name: currentPresenter.name, muted: !!currentPresenter.muted }]
    : [];
}

function broadcastPresenters() {
  const payload = JSON.stringify({ type: "presenters", presenters: presentersList() });
  for (const c of clients) {
    if (c.readyState === WebSocket.OPEN) c.send(payload);
  }
}

function stopStream(reason = "stopped") {
  if (ffmpegProc) {
    try {
      ffmpegProc.stdin.end();
    } catch {}
    try {
      ffmpegProc.kill("SIGINT");
    } catch {}
  }
  ffmpegProc = null;

  if (publisherWs) send(publisherWs, { type: "publish_stopped", reason });
  publisherWs = null;
  currentPresenter = null;

  broadcastPresenters();
}

// Viewer API: seznam přednášejících (aktuálně 0/1)
app.get("/api/presenters", (_req, res) => {
  res.json({ presenters: presentersList() });
});

wss.on("connection", (ws) => {
  clients.add(ws);
  ws.isPublisher = false;

  // hned po připojení pošli aktuální stav
  send(ws, { type: "hello", presenters: presentersList() });

  ws.on("message", (data, isBinary) => {
    // 1) Binární = WebM chunk (jen od publishera)
    // POZOR: ve ws knihovně může být i text doručen jako Buffer, proto se rozhodujeme POUZE podle isBinary.
    if (isBinary) {
      if (!ws.isPublisher) return;
      if (!ffmpegProc || !ffmpegProc.stdin || !ffmpegProc.stdin.writable) return;
      ffmpegProc.stdin.write(data);
      return;
    }

    // 2) Text = JSON
    const text = Buffer.isBuffer(data) ? data.toString("utf8") : String(data);
    let msg;
    try {
      msg = JSON.parse(text);
    } catch {
      return;
    }

    if (msg.type === "ping") {
      send(ws, { type: "pong", ts: Date.now() });
      return;
    }

    if (msg.type === "publish_start") {
      const name = String(msg.name || "").trim();
      const key = String(msg.key || "").trim();
      const muted = !!msg.muted;

      console.log("publish_start:", { name, muted, keyOk: key === PUBLISH_KEY });

      if (!name) {
        send(ws, { type: "publish_error", detail: "Chybí jméno." });
        return;
      }
      if (!key || key !== PUBLISH_KEY) {
        send(ws, { type: "publish_error", detail: "Špatný publikační klíč." });
        return;
      }

      // dovolíme pouze 1 publisher
      if (publisherWs && publisherWs !== ws) {
        send(ws, { type: "publish_error", detail: "Už běží jiné vysílání (1 stream max)." });
        return;
      }

      // restart, když stejný klient znovu startuje
      if (publisherWs === ws && ffmpegProc) stopStream("restart");

      try {
        ffmpegProc = startFfmpegWebmToHls(HLS_DIR);
        publisherWs = ws;
        ws.isPublisher = true;

        currentPresenter = {
          id: "main",
          name,
          muted,
          startedAt: Date.now(),
          lastSeen: Date.now(),
        };

        ffmpegProc.on("exit", () => {
          // když ffmpeg spadne, ukončíme stream stav
          stopStream("ffmpeg_exit");
        });

        send(ws, { type: "publish_ok", id: currentPresenter.id });

        broadcastPresenters();
      } catch (e) {
        stopStream("ffmpeg_start_failed");
        send(ws, { type: "publish_error", detail: `FFmpeg start failed: ${e?.message || e}` });
      }
      return;
    }

    if (msg.type === "set_muted") {
      if (currentPresenter) {
        currentPresenter.muted = !!msg.muted;
        broadcastPresenters();
      }
      return;
    }

    if (msg.type === "publish_stop") {
      if (ws.isPublisher) stopStream("client_stop");
      return;
    }
  });

  ws.on("close", () => {
    clients.delete(ws);
    if (ws.isPublisher) stopStream("publisher_disconnected");
  });
});

server.listen(PORT, () => {
  console.log(`Node server: http://127.0.0.1:${PORT}`);
  console.log(`WS path: /ws`);
  console.log(`HLS_DIR: ${HLS_DIR}`);
});
