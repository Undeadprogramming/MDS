let stream = null;
let ws = null;
let isMuted = false;
let isPublishing = false;
let presenterId = null;

// MediaRecorder (místo WebRTC)
let recorder = null;

// WS heartbeat
let wsHeartbeatTimer = null;

const el = (id) => document.getElementById(id);

function log(msg) {
  const box = el("log");
  const ts = new Date().toISOString().slice(11, 19);
  box.textContent += `[${ts}] ${msg}\n`;
  box.scrollTop = box.scrollHeight;
}

function setStatus(text, kind = "secondary") {
  const b = el("badgeStatus");
  b.textContent = text;
  b.className = `badge text-bg-${kind}`;
}

function setWsState(text) {
  el("wsState").textContent = text;
}

function canPublish() {
  const nameOk = el("name").value.trim().length > 0;
  const keyOk = el("key").value.trim().length > 0;
  return !!stream && nameOk && keyOk && ws && ws.readyState === WebSocket.OPEN;
}

function startWsHeartbeat() {
  stopWsHeartbeat();
  wsHeartbeatTimer = setInterval(() => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: "ping", ts: Date.now() }));
    }
  }, 25000); // 25s
}

function stopWsHeartbeat() {
  if (wsHeartbeatTimer) clearInterval(wsHeartbeatTimer);
  wsHeartbeatTimer = null;
}

async function startPreview() {
  try {
    setStatus("requesting", "warning");
    log("Žádám o přístup ke kameře a mikrofonu...");

    stream = await navigator.mediaDevices.getUserMedia({
      video: { width: 1280, height: 720, frameRate: 30 },
      audio: { channelCount: 2, sampleRate: 48000 },
    });

    el("preview").srcObject = stream;
    setStatus("preview", "success");
    log("Náhled zapnut.");

    el("btnStop").disabled = false;
    el("btnMute").disabled = false;
    el("btnPublishStart").disabled = !canPublish();
  } catch (e) {
    setStatus("error", "danger");
    log(`Chyba getUserMedia: ${e?.message || e}`);
    alert("Nepodařilo se získat kameru/mikrofon. Zkontroluj oprávnění v prohlížeči.");
  }
}

function stopRecorder(reason = "") {
  if (recorder) {
    try {
      recorder.ondataavailable = null;
      recorder.onerror = null;
      recorder.stop();
    } catch {}
  }
  recorder = null;
  if (reason) log(`Recorder stop (${reason})`);
}

function stopAll() {
  if (isPublishing) publishStop();

  stopRecorder("stopAll");

  if (stream) {
    stream.getTracks().forEach((t) => t.stop());
    stream = null;
  }
  el("preview").srcObject = null;
  isMuted = false;

  el("btnStop").disabled = true;
  el("btnMute").disabled = true;
  el("btnPublishStart").disabled = true;
  el("btnPublishStop").disabled = true;

  el("btnMute").textContent = "Ztlumit mic";
  setStatus("idle", "secondary");
  log("Zastaveno.");
}

function toggleMute() {
  if (!stream) return;

  const audioTracks = stream.getAudioTracks();
  if (audioTracks.length === 0) {
    log("Nemám audio track, není co ztlumit.");
    return;
  }

  isMuted = !isMuted;
  audioTracks.forEach((t) => (t.enabled = !isMuted));

  el("btnMute").textContent = isMuted ? "Odtlumit mic" : "Ztlumit mic";
  log(isMuted ? "Mikrofon ztlumen." : "Mikrofon zapnut.");

  if (isPublishing && ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: "set_muted", muted: isMuted }));
  }
}

function pickMimeType() {
  if (window.MediaRecorder?.isTypeSupported?.("video/webm;codecs=vp8,opus")) {
    return "video/webm;codecs=vp8,opus";
  }
  if (window.MediaRecorder?.isTypeSupported?.("video/webm")) {
    return "video/webm";
  }
  return "";
}

function startRecorder() {
  if (!stream) {
    log("Recorder: není stream.");
    return;
  }
  if (!ws || ws.readyState !== WebSocket.OPEN) {
    log("Recorder: WS není open.");
    return;
  }
  if (recorder) {
    log("Recorder: už běží.");
    return;
  }

  const mimeType = pickMimeType();
  if (!mimeType) {
    alert("Tento prohlížeč nepodporuje MediaRecorder do WebM. Zkus Chrome/Edge.");
    return;
  }

  recorder = new MediaRecorder(stream, {
    mimeType,
    videoBitsPerSecond: 2_500_000,
  });

  recorder.ondataavailable = async (e) => {
    if (!e.data || e.data.size === 0) return;
    if (!ws || ws.readyState !== WebSocket.OPEN) return;

    const buf = await e.data.arrayBuffer();
    ws.send(buf); // binární chunk do Node serveru (FFmpeg stdin)
  };

  recorder.onerror = (e) => {
    log(`Recorder error: ${e?.message || e}`);
    publishStop();
  };

  recorder.start(250); // chunk každých 250ms (nižší latence)
  log(`Recorder start: ${mimeType}`);

  el("btnPublishStart").disabled = true;
  el("btnPublishStop").disabled = false;
}

function connectWs() {
  // tvoje nginx přesměrovává 80->443, takže stránka jede na https => wss je správně
  const url = `wss://${location.host}/ws`;
  ws = new WebSocket(url);
  ws.binaryType = "arraybuffer";

  setWsState("connecting...");
  ws.onopen = () => {
    setWsState("connected");
    log(`WS připojeno: ${url}`);

    startWsHeartbeat();
    el("btnPublishStart").disabled = !canPublish();
  };

  ws.onmessage = async (ev) => {
    const data = ev.data;

    if (typeof data === "string" && data.includes('"type":"pong"')) return;

    log(`WS <= ${data}`);

    try {
      const msg = JSON.parse(data);

      if (msg.type === "publish_ok") {
        presenterId = msg.id || "main";
        isPublishing = true;

        el("btnPublishStart").disabled = true;
        el("btnPublishStop").disabled = false;
        setStatus(`publishing(${presenterId})`, "primary");

        startRecorder();
      }

      if (msg.type === "publish_stopped") {
        presenterId = null;
        isPublishing = false;

        stopRecorder("publish_stopped");

        el("btnPublishStart").disabled = !canPublish();
        el("btnPublishStop").disabled = true;
        setStatus(stream ? "preview" : "idle", stream ? "success" : "secondary");
      }

      if (msg.type === "publish_error") {
        alert(msg.detail || "Publish error");
        stopRecorder("publish_error");

        el("btnPublishStart").disabled = !canPublish();
        el("btnPublishStop").disabled = true;
        setStatus("preview", "success");
      }
    } catch (_) {
      // ignore parse errors
    }
  };

  ws.onclose = (ev) => {
    setWsState("disconnected");
    log(`WS odpojeno. code=${ev.code} reason=${ev.reason || "(none)"}`);

    stopWsHeartbeat();
    stopRecorder("ws_close");

    el("btnPublishStart").disabled = true;
    el("btnPublishStop").disabled = true;
  };

  ws.onerror = () => {
    log("WS chyba (detail v konzoli prohlížeče).");
  };
}

function publishStart() {
  if (!canPublish()) {
    alert("Musíš mít zapnutý náhled, vyplnit jméno i klíč a WS musí být connected.");
    return;
  }

  const msg = {
    type: "publish_start",
    name: el("name").value.trim(),
    key: el("key").value.trim(),
    muted: isMuted,
    ts: Date.now(),
  };

  ws.send(JSON.stringify(msg));
  log(`WS => ${JSON.stringify(msg)}`);
}

function publishStop() {
  if (ws && ws.readyState === WebSocket.OPEN) {
    stopRecorder("publishStop()");
    ws.send(JSON.stringify({ type: "publish_stop", ts: Date.now() }));
    log(`WS => {"type":"publish_stop"}`);
  }
}

window.addEventListener("DOMContentLoaded", () => {
  connectWs();

  el("btnPreview").addEventListener("click", startPreview);
  el("btnStop").addEventListener("click", stopAll);
  el("btnMute").addEventListener("click", toggleMute);

  el("btnPublishStart").addEventListener("click", publishStart);
  el("btnPublishStop").addEventListener("click", publishStop);

  const onInput = () => {
    el("btnPublishStart").disabled = !canPublish() || isPublishing;
  };
  el("name").addEventListener("input", onInput);
  el("key").addEventListener("input", onInput);

  setStatus("idle", "secondary");
  log("Stránka načtena.");
});
