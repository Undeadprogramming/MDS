const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const crypto = require("crypto");
const wrtc = require("wrtc");

const { spawn } = require("child_process");
const path = require("path");
const fs = require("fs");

// node-webrtc nonstandard sinks
const { RTCVideoSink, RTCAudioSink } = wrtc.nonstandard;

const PORT = process.env.PORT || 3000;
const PUBLISH_KEY = process.env.PUBLISH_KEY || "mds2025";
const MAX_PUBLISHERS = 6;

const app = express();
app.use(express.json());

// id -> {id,name,muted,startedAt,lastSeen}
const presenters = new Map();
// ws -> {role, presenterId}
const wsMeta = new Map();

// ws -> RTCPeerConnection
const peerConnections = new Map();

// ws -> cleanup (ffmpeg + sinks)
const ffCleanups = new Map();

function presentersList() {
  return Array.from(presenters.values()).map((p) => ({
    id: p.id,
    name: p.name,
    muted: p.muted,
    startedAt: p.startedAt,
    lastSeen: p.lastSeen,
  }));
}

app.get("/api/status", (req, res) => {
  res.json({
    ok: true,
    time: new Date().toISOString(),
    presenters: presentersList().length,
  });
});

app.get("/api/presenters", (req, res) => {
  res.json({ presenters: presentersList() });
});

const server = http.createServer(app);
const serverWss = new WebSocket.Server({ server, path: "/ws" });

function send(ws, obj) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}

function broadcast(obj) {
  const msg = JSON.stringify(obj);
  for (const client of serverWss.clients) {
    if (client.readyState === WebSocket.OPEN) client.send(msg);
  }
}

function isPublisher(ws) {
  const meta = wsMeta.get(ws);
  return meta?.role === "publisher" && !!meta.presenterId && presenters.has(meta.presenterId);
}

/* =========================
   Helpers: FS
   ========================= */

function ensureDir(p) {
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
}

/* =========================
   I420 packing (fix pro rozbitý obraz)
   ========================= */

/**
 * node-webrtc může posílat I420 frame s paddingem/stride.
 * ffmpeg rawvideo očekává tightly-packed yuv420p: W*H*1.5 bytes.
 * Pokud frame.data.length != expected, přebalíme po řádcích.
 */
function packI420(frame) {
  const w = frame.width;
  const h = frame.height;

  const out = Buffer.allocUnsafe((w * h * 3) >> 1);
  const src = Buffer.from(frame.data);

  // Strides: někdy jsou ve frame.stride, někdy strideY/strideU/strideV, někdy nic.
  const strideY =
    (frame.stride && frame.stride.y) ??
    frame.strideY ??
    w;

  const strideU =
    (frame.stride && frame.stride.u) ??
    frame.strideU ??
    (w >> 1);

  const strideV =
    (frame.stride && frame.stride.v) ??
    frame.strideV ??
    (w >> 1);

  // Velikosti plane v input buffru při stride
  const yPlaneSize = strideY * h;
  const uPlaneSize = strideU * (h >> 1);
  const vPlaneSize = strideV * (h >> 1);

  let outOff = 0;

  // Y plane
  for (let y = 0; y < h; y++) {
    const srcStart = y * strideY;
    const srcEnd = srcStart + w;
    src.copy(out, outOff, srcStart, srcEnd);
    outOff += w;
  }

  // U plane
  const uBase = yPlaneSize;
  for (let y = 0; y < (h >> 1); y++) {
    const srcStart = uBase + y * strideU;
    const srcEnd = srcStart + (w >> 1);
    src.copy(out, outOff, srcStart, srcEnd);
    outOff += (w >> 1);
  }

  // V plane
  const vBase = yPlaneSize + uPlaneSize;
  for (let y = 0; y < (h >> 1); y++) {
    const srcStart = vBase + y * strideV;
    const srcEnd = srcStart + (w >> 1);
    src.copy(out, outOff, srcStart, srcEnd);
    outOff += (w >> 1);
  }

  return out;
}

/* =========================
   FFmpeg: HLS 3 variants (720/480/360) + master.m3u8
   ========================= */

function startFfmpegHls3Variants({ width, height, fps, hlsDir }) {
  // zajisti složky
  ensureDir(hlsDir);
  ensureDir(path.join(hlsDir, "v0"));
  ensureDir(path.join(hlsDir, "v1"));
  ensureDir(path.join(hlsDir, "v2"));

  // DŮLEŽITÉ: používáme relativní cesty a nastavíme cwd = hlsDir
  // aby ffmpeg generoval: hls/master.m3u8 + hls/v0..v2/*
  const args = [
    // VIDEO input: pipe:3 (I420)
    "-f", "rawvideo",
    "-pix_fmt", "yuv420p",
    "-s", `${width}x${height}`,
    "-r", String(fps),
    "-i", "pipe:3",

    // AUDIO input: pipe:4 (PCM s16le, 48k, stereo)
    "-f", "s16le",
    "-ar", "48000",
    "-ac", "2",
    "-i", "pipe:4",

    // video split + scale
    "-filter_complex",
    "[0:v]split=3[v720][v480][v360];" +
      "[v720]scale=w=1280:h=720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2[v0];" +
      "[v480]scale=w=854:h=480:force_original_aspect_ratio=decrease,pad=854:480:(ow-iw)/2:(oh-ih)/2[v1];" +
      "[v360]scale=w=640:h=360:force_original_aspect_ratio=decrease,pad=640:360:(ow-iw)/2:(oh-ih)/2[v2]",

    // map: 3 varianty + audio
    "-map", "[v0]", "-map", "1:a",
    "-map", "[v1]", "-map", "1:a",
    "-map", "[v2]", "-map", "1:a",

    // video encode: když CPU nestíhá, změň preset na ultrafast
    "-c:v", "libx264",
    "-preset", "ultrafast",
    "-tune", "zerolatency",
    "-profile:v", "main",
    "-g", String(fps * 2),
    "-keyint_min", String(fps * 2),
    "-sc_threshold", "0",

    // bitraty (720/480/360)
    "-b:v:0", "2500k", "-maxrate:v:0", "2800k", "-bufsize:v:0", "5000k",
    "-b:v:1", "1200k", "-maxrate:v:1", "1500k", "-bufsize:v:1", "2400k",
    "-b:v:2", "800k",  "-maxrate:v:2", "1000k", "-bufsize:v:2", "1600k",

    // audio encode
    "-c:a", "aac",
    "-b:a", "128k",
    "-ac", "2",
    "-ar", "48000",

    // HLS
    "-f", "hls",
    "-hls_time", "8",
    "-hls_list_size", "200", // ~20 min při 6s segmentech
    "-hls_flags", "independent_segments+delete_segments+append_list",
    "-hls_segment_filename", "v%v/seg_%05d.ts",

    // master playlist (POUZE název, ne absolutní cesta!)
    "-master_pl_name", "master.m3u8",
    "-var_stream_map", "v:0,a:0 v:1,a:1 v:2,a:2",
    "v%v/prog_index.m3u8",

    "-threads", "0",

  ];

  console.log("FFmpeg: starting in", hlsDir, "input:", `${width}x${height}@${fps}`);

  const ff = spawn("ffmpeg", args, {
    cwd: hlsDir,
    stdio: ["ignore", "inherit", "inherit", "pipe", "pipe"], // 3 video, 4 audio
  });

  ff.on("exit", (code, sig) => {
    console.log("FFmpeg exited:", { code, sig });
  });

  return ff;
}

/* =========================
   Attach WebRTC tracks -> FFmpeg
   ========================= */

function attachMediaToFfmpeg(ws, pc) {
  const hlsDir = path.resolve(__dirname, "../nginx/site/hls");
  ensureDir(hlsDir);
  ensureDir(path.join(hlsDir, "v0"));
  ensureDir(path.join(hlsDir, "v1"));
  ensureDir(path.join(hlsDir, "v2"));

  let ff = null;
  let videoSink = null;
  let audioSink = null;

  const fps = 30;
  let stopping = false;

  function safeWrite(stream, buf) {
    if (!stream || stopping) return;
    if (stream.destroyed || stream.writableEnded) return;
    try {
      stream.write(buf);
    } catch (_) {
      // ignoruj - typicky při shutdown
    }
  }

  function startFfIfNeeded(frame) {
    if (ff || stopping) return;

    ff = startFfmpegHls3Variants({
      width: frame.width,
      height: frame.height,
      fps,
      hlsDir,
    });

    // ✅ aby Node nespadl na write EOF
    const vPipe = ff.stdio[3];
    const aPipe = ff.stdio[4];

    vPipe.on("error", (e) => {
      // EOF při ukončení je OK
      if (e?.code !== "EOF") console.log("ffmpeg video pipe error:", e?.code || e);
    });

    aPipe.on("error", (e) => {
      if (e?.code !== "EOF") console.log("ffmpeg audio pipe error:", e?.code || e);
    });
  }

  pc.addEventListener("track", (ev) => {
    if (ev.track.kind === "video" && !videoSink) {
      console.log("FF: video track attached");
      videoSink = new RTCVideoSink(ev.track);

      videoSink.onframe = ({ frame }) => {
        if (stopping) return;

        startFfIfNeeded(frame);

        if (!ff) return;

        const expected = (frame.width * frame.height * 3) >> 1;
        const buf = (frame.data.length === expected) ? Buffer.from(frame.data) : packI420(frame);

        safeWrite(ff.stdio[3], buf);
      };
    }

    if (ev.track.kind === "audio" && !audioSink) {
      console.log("FF: audio track attached");
      audioSink = new RTCAudioSink(ev.track);

      audioSink.ondata = (data) => {
        if (stopping) return;
        if (!ff) return;

        safeWrite(ff.stdio[4], Buffer.from(data.samples.buffer));
      };
    }
  });

  const cleanup = () => {
    if (stopping) return;
    stopping = true;

    try { videoSink?.stop(); } catch {}
    try { audioSink?.stop(); } catch {}

    // zavři vstupy do ffmpeg bezpečně
    try { ff?.stdio?.[3]?.end(); } catch {}
    try { ff?.stdio?.[4]?.end(); } catch {}

    // ukonči ffmpeg
    try { ff?.kill("SIGINT"); } catch {}

    ff = null;
  };

  pc.addEventListener("connectionstatechange", () => {
    if (["failed", "disconnected", "closed"].includes(pc.connectionState)) {
      console.log("FF: cleanup due to pc state", pc.connectionState);
      cleanup();
    }
  });

  ws.on("close", () => cleanup());

  return cleanup;
}

/* =========================
   WebRTC lifecycle
   ========================= */

function closePeer(ws, reason = "") {
  // nejdřív ukliď ffmpeg
  const ffCleanup = ffCleanups.get(ws);
  if (ffCleanup) {
    try { ffCleanup(); } catch {}
    ffCleanups.delete(ws);
  }

  const pc = peerConnections.get(ws);
  if (!pc) return;

  try {
    pc.onicecandidate = null;
    pc.ontrack = null;
    pc.onconnectionstatechange = null;
    pc.close();
  } catch (_) {}

  peerConnections.delete(ws);
  if (reason) console.log(`WebRTC: PC closed (${reason})`);
}

function cleanupPublisher(ws) {
  closePeer(ws, "cleanupPublisher");

  const meta = wsMeta.get(ws);
  if (!meta || !meta.presenterId) return;

  const id = meta.presenterId;
  if (presenters.has(id)) {
    const p = presenters.get(id);
    presenters.delete(id);
    broadcast({
      type: "presenters",
      presenters: presentersList(),
      reason: "publisher_left",
      left: p?.name,
    });
  }
}

function createPeer(ws) {
  const pc = new wrtc.RTCPeerConnection({
    iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
  });

  // attach media -> ffmpeg
  const ffCleanup = attachMediaToFfmpeg(ws, pc);
  ffCleanups.set(ws, ffCleanup);

  pc.onicecandidate = ({ candidate }) => {
    if (candidate) send(ws, { type: "webrtc-ice", candidate });
  };

  pc.onconnectionstatechange = () => {
    console.log("WebRTC: connectionState =", pc.connectionState);
    if (pc.connectionState === "failed" || pc.connectionState === "closed") {
      closePeer(ws, `state=${pc.connectionState}`);
    }
  };

  pc.ontrack = (ev) => {
    console.log("WebRTC: track received:", ev.track.kind);
  };

  peerConnections.set(ws, pc);
  return pc;
}

async function handleOffer(ws, sdp) {
  if (!isPublisher(ws)) {
    send(ws, { type: "webrtc-error", detail: "not_publisher" });
    return;
  }

  const pc = peerConnections.get(ws) || createPeer(ws);

  await pc.setRemoteDescription(new wrtc.RTCSessionDescription(sdp));
  const answer = await pc.createAnswer();
  await pc.setLocalDescription(answer);

  send(ws, { type: "webrtc-answer", sdp: pc.localDescription });
}

async function handleIce(ws, candidate) {
  const pc = peerConnections.get(ws);
  if (!pc) return;
  try {
    await pc.addIceCandidate(new wrtc.RTCIceCandidate(candidate));
  } catch (e) {
    console.log("WebRTC: addIceCandidate error:", e?.message || e);
  }
}

/* =========================
   WebSocket
   ========================= */

serverWss.on("connection", (ws) => {
  wsMeta.set(ws, { role: "client", presenterId: null });

  send(ws, {
    type: "hello",
    msg: "ws connected",
    presenters: presentersList(),
    maxPublishers: MAX_PUBLISHERS,
  });

  ws.on("message", async (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch (e) {
      send(ws, { type: "error", error: "bad_json" });
      return;
    }

    const meta = wsMeta.get(ws) || { role: "client", presenterId: null };

    // lastSeen
    if (meta.presenterId && presenters.has(meta.presenterId)) {
      presenters.get(meta.presenterId).lastSeen = Date.now();
    }

    try {
      switch (msg.type) {
        case "get_presenters":
          send(ws, { type: "presenters", presenters: presentersList() });
          return;

        // heartbeat z klienta (můžeš nechat)
        case "ping":
          if (meta.presenterId && presenters.has(meta.presenterId)) {
            presenters.get(meta.presenterId).lastSeen = Date.now();
          }
          send(ws, { type: "pong", ts: Date.now() });
          return;

        case "publish_start": {
          const name = String(msg.name || "").trim();
          const key = String(msg.key || "").trim();
          const muted = !!msg.muted;

          if (!name || name.length < 2 || name.length > 32) {
            send(ws, { type: "publish_error", error: "bad_name", detail: "Jméno musí mít 2–32 znaků." });
            return;
          }
          if (key !== PUBLISH_KEY) {
            send(ws, { type: "publish_error", error: "bad_key", detail: "Špatný publikační klíč." });
            return;
          }
          if (presenters.size >= MAX_PUBLISHERS) {
            send(ws, { type: "publish_error", error: "limit", detail: `Max ${MAX_PUBLISHERS} publikujících.` });
            return;
          }

          cleanupPublisher(ws);

          const id = crypto.randomUUID().slice(0, 8);
          presenters.set(id, {
            id,
            name,
            muted,
            startedAt: Date.now(),
            lastSeen: Date.now(),
          });

          wsMeta.set(ws, { role: "publisher", presenterId: id });

          send(ws, { type: "publish_ok", id, name, muted });
          broadcast({ type: "presenters", presenters: presentersList(), reason: "publisher_joined", joined: name });
          return;
        }

        case "publish_stop":
          cleanupPublisher(ws);
          wsMeta.set(ws, { role: "client", presenterId: null });
          send(ws, { type: "publish_stopped" });
          return;

        case "set_muted": {
          const muted = !!msg.muted;
          if (!meta.presenterId || !presenters.has(meta.presenterId)) {
            send(ws, { type: "error", error: "not_publisher" });
            return;
          }
          const p = presenters.get(meta.presenterId);
          p.muted = muted;
          p.lastSeen = Date.now();
          broadcast({ type: "presenters", presenters: presentersList(), reason: "mute_changed", name: p.name, muted });
          return;
        }

        // WebRTC signalizace
        case "webrtc-offer":
          await handleOffer(ws, msg.sdp);
          return;

        case "webrtc-ice":
          await handleIce(ws, msg.candidate);
          return;

        default:
          send(ws, { type: "error", error: "unknown_type", got: msg.type });
          return;
      }
    } catch (e) {
      console.log("WS handler error:", e);
      send(ws, { type: "error", error: "server_error", detail: e?.message || String(e) });
    }
  });

  ws.on("close", () => {
    cleanupPublisher(ws);
    wsMeta.delete(ws);
  });
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`Node API+WS running on http://127.0.0.1:${PORT}`);
  console.log(`PUBLISH_KEY=${PUBLISH_KEY} (nastav env var PUBLISH_KEY pro změnu)`);
});
