const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const crypto = require("crypto");

const PORT = process.env.PORT || 3000;
const PUBLISH_KEY = process.env.PUBLISH_KEY || "mds2025"; // změň / nebo nastav env var
const MAX_PUBLISHERS = 6;

const app = express();
app.use(express.json());

// id -> {id,name,muted,startedAt,lastSeen}
const presenters = new Map();
// ws -> {role, presenterId}
const wsMeta = new Map();

function presentersList() {
  return Array.from(presenters.values()).map((p) => ({
    id: p.id,
    name: p.name,
    muted: p.muted,
    startedAt: p.startedAt,
    lastSeen: p.lastSeen,
  }));
}

app.get("/api/status", (req, res) => {
  res.json({
    ok: true,
    time: new Date().toISOString(),
    presenters: presentersList().length,
  });
});

app.get("/api/presenters", (req, res) => {
  res.json({ presenters: presentersList() });
});

const server = http.createServer(app);

function send(ws, obj) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}

function broadcast(obj) {
  const msg = JSON.stringify(obj);
  for (const client of serverWss.clients) {
    if (client.readyState === WebSocket.OPEN) client.send(msg);
  }
}

function cleanupPublisher(ws) {
  const meta = wsMeta.get(ws);
  if (!meta || !meta.presenterId) return;

  const id = meta.presenterId;
  if (presenters.has(id)) {
    const p = presenters.get(id);
    presenters.delete(id);
    broadcast({ type: "presenters", presenters: presentersList(), reason: "publisher_left", left: p?.name });
  }
}

const serverWss = new WebSocket.Server({ server, path: "/ws" });

serverWss.on("connection", (ws) => {
  wsMeta.set(ws, { role: "client", presenterId: null });

  // po připojení pošli aktuální stav
  send(ws, { type: "hello", msg: "ws connected", presenters: presentersList(), maxPublishers: MAX_PUBLISHERS });

  ws.on("message", (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch (e) {
      return send(ws, { type: "error", error: "bad_json" });
    }

    const meta = wsMeta.get(ws) || { role: "client", presenterId: null };

    // pomocná aktualizace lastSeen
    if (meta.presenterId && presenters.has(meta.presenterId)) {
      const p = presenters.get(meta.presenterId);
      p.lastSeen = Date.now();
    }

    switch (msg.type) {
      case "get_presenters": {
        return send(ws, { type: "presenters", presenters: presentersList() });
      }

      case "publish_start": {
        const name = String(msg.name || "").trim();
        const key = String(msg.key || "").trim();
        const muted = !!msg.muted;

        if (!name || name.length < 2 || name.length > 32) {
          return send(ws, { type: "publish_error", error: "bad_name", detail: "Jméno musí mít 2–32 znaků." });
        }
        if (key !== PUBLISH_KEY) {
          return send(ws, { type: "publish_error", error: "bad_key", detail: "Špatný publikační klíč." });
        }
        if (presenters.size >= MAX_PUBLISHERS) {
          return send(ws, { type: "publish_error", error: "limit", detail: `Max ${MAX_PUBLISHERS} publikujících.` });
        }

        // pokud už ten WS je publisher, nejdřív ho zruš
        cleanupPublisher(ws);

        const id = crypto.randomUUID().slice(0, 8);
        presenters.set(id, {
          id,
          name,
          muted,
          startedAt: Date.now(),
          lastSeen: Date.now(),
        });

        wsMeta.set(ws, { role: "publisher", presenterId: id });

        send(ws, { type: "publish_ok", id, name, muted });
        broadcast({ type: "presenters", presenters: presentersList(), reason: "publisher_joined", joined: name });
        return;
      }

      case "publish_stop": {
        cleanupPublisher(ws);
        wsMeta.set(ws, { role: "client", presenterId: null });
        send(ws, { type: "publish_stopped" });
        return;
      }

      case "set_muted": {
        const muted = !!msg.muted;
        if (!meta.presenterId || !presenters.has(meta.presenterId)) {
          return send(ws, { type: "error", error: "not_publisher" });
        }
        const p = presenters.get(meta.presenterId);
        p.muted = muted;
        p.lastSeen = Date.now();
        broadcast({ type: "presenters", presenters: presentersList(), reason: "mute_changed", name: p.name, muted });
        return;
      }

      // WebRTC signalling zatím jen připravíme (implementace v dalším kroku)
      case "webrtc_offer":
      case "webrtc_ice": {
        return send(ws, { type: "webrtc_error", error: "not_implemented_yet" });
      }

      default:
        return send(ws, { type: "error", error: "unknown_type", got: msg.type });
    }
  });

  ws.on("close", () => {
    cleanupPublisher(ws);
    wsMeta.delete(ws);
  });
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`Node API+WS running on http://127.0.0.1:${PORT}`);
  console.log(`PUBLISH_KEY=${PUBLISH_KEY} (nastav env var PUBLISH_KEY pro změnu)`);
});
