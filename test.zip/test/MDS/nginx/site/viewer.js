const STREAM_SRC = "/hls/master.m3u8";
const CHECK_EVERY_MS = 5000;

let player = null;
let ws = null;

const el = (id) => document.getElementById(id);

function setWsBadge(text, kind) {
  const b = el("wsState");
  b.textContent = text;
  b.className = `badge text-bg-${kind}`;
}

function renderPresenters(list) {
  const ul = el("presenters");
  ul.innerHTML = "";
  if (!list || list.length === 0) {
    ul.innerHTML = '<li class="list-group-item text-muted">Nikdo aktuálně nevysílá.</li>';
    return;
  }
  for (const p of list) {
    const li = document.createElement("li");
    li.className = "list-group-item d-flex justify-content-between align-items-center";
    li.innerHTML = `
      <div>
        <div class="fw-semibold">${escapeHtml(p.name)}</div>
        <div class="small text-muted mono">id=${escapeHtml(p.id)} • muted=${p.muted}</div>
      </div>
      <span class="badge text-bg-primary">LIVE</span>
    `;
    ul.appendChild(li);
  }
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
}

async function streamExists() {
  try {
    const r = await fetch(STREAM_SRC, { method: "GET", cache: "no-store" });
    return r.ok;
  } catch {
    return false;
  }
}

async function ensurePlayer() {
  if (!player) {
    player = videojs("player");
  }
  const ok = await streamExists();
  el("waiting").style.display = ok ? "none" : "flex";

  if (ok) {
    const current = player.currentSrc();
    if (!current || !current.includes(STREAM_SRC)) {
      player.src({ src: STREAM_SRC, type: "application/x-mpegURL" });
      player.play().catch(() => {});
      setupQualitySelector();
    }
  } else {
    try { player.pause(); } catch {}
  }
}

function setupQualitySelector() {
  const qsel = el("qualitySel");
  const ql = player.qualityLevels && player.qualityLevels();
  if (!ql) return;

  const seen = new Set();
  function rebuildOptions() {
    // keep "Auto"
    const current = qsel.value;
    qsel.querySelectorAll("option").forEach((o) => { if (o.value !== "auto") o.remove(); });

    for (let i = 0; i < ql.length; i++) {
      const lvl = ql[i];
      if (!lvl.height) continue;
      const key = String(lvl.height);
      if (seen.has(key)) continue;
      seen.add(key);

      const opt = document.createElement("option");
      opt.value = key;
      opt.textContent = `${lvl.height}p`;
      qsel.appendChild(opt);
    }

    // restore selection if possible
    if ([...qsel.options].some(o => o.value === current)) qsel.value = current;
  }

  ql.on("addqualitylevel", rebuildOptions);
  rebuildOptions();

  qsel.onchange = () => {
    const v = qsel.value;
    if (v === "auto") {
      for (let i = 0; i < ql.length; i++) ql[i].enabled = true;
      return;
    }
    const target = parseInt(v, 10);
    for (let i = 0; i < ql.length; i++) {
      const lvl = ql[i];
      lvl.enabled = (lvl.height === target);
    }
  };
}

function connectWs() {
  const url = `wss://${location.host}/ws`;
  ws = new WebSocket(url);
  setWsBadge("WS: connecting", "warning");

  ws.onopen = () => setWsBadge("WS: connected", "success");
  ws.onclose = () => setWsBadge("WS: disconnected", "secondary");
  ws.onerror = () => setWsBadge("WS: error", "danger");

  ws.onmessage = (ev) => {
    try {
      const msg = JSON.parse(ev.data);
      if (msg.type === "hello" && msg.presenters) renderPresenters(msg.presenters);
      if (msg.type === "presenters" && msg.presenters) renderPresenters(msg.presenters);
    } catch {}
  };
}

async function initialPresentersFetch() {
  try {
    const r = await fetch("/api/presenters", { cache: "no-store" });
    if (!r.ok) return;
    const data = await r.json();
    renderPresenters(data.presenters || []);
  } catch {}
}

window.addEventListener("DOMContentLoaded", async () => {
  el("streamUrl").textContent = STREAM_SRC;

  connectWs();
  await initialPresentersFetch();
  await ensurePlayer();

  el("btnReload").addEventListener("click", async () => {
    if (player) player.reset();
    await ensurePlayer();
  });

  setInterval(ensurePlayer, CHECK_EVERY_MS);
});
