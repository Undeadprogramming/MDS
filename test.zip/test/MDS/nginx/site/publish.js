let stream = null;
let ws = null;
let isMuted = false;
let isPublishing = false;
let presenterId = null;

const el = (id) => document.getElementById(id);

function log(msg) {
  const box = el("log");
  const ts = new Date().toISOString().slice(11, 19);
  box.textContent += `[${ts}] ${msg}\n`;
  box.scrollTop = box.scrollHeight;
}

function setStatus(text, kind = "secondary") {
  const b = el("badgeStatus");
  b.textContent = text;
  b.className = `badge text-bg-${kind}`;
}

function setWsState(text) {
  el("wsState").textContent = text;
}

function canPublish() {
  const nameOk = el("name").value.trim().length > 0;
  const keyOk = el("key").value.trim().length > 0;
  return !!stream && nameOk && keyOk && ws && ws.readyState === WebSocket.OPEN;
}

async function startPreview() {
  try {
    setStatus("requesting", "warning");
    log("Žádám o přístup ke kameře a mikrofonu...");
    stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });

    el("preview").srcObject = stream;
    setStatus("preview", "success");
    log("Náhled zapnut.");

    el("btnStop").disabled = false;
    el("btnMute").disabled = false;
    el("btnPublishStart").disabled = !canPublish();
  } catch (e) {
    setStatus("error", "danger");
    log(`Chyba getUserMedia: ${e?.message || e}`);
    alert("Nepodařilo se získat kameru/mikrofon. Zkontroluj oprávnění v prohlížeči.");
  }
}

function stopAll() {
  if (stream) {
    stream.getTracks().forEach(t => t.stop());
    stream = null;
  }
  el("preview").srcObject = null;
  isMuted = false;

  if (isPublishing) publishStop();

  el("btnStop").disabled = true;
  el("btnMute").disabled = true;
  el("btnPublishStart").disabled = true;
  el("btnPublishStop").disabled = true;

  el("btnMute").textContent = "Ztlumit mic";
  setStatus("idle", "secondary");
  log("Zastaveno.");
}

function toggleMute() {
  if (!stream) return;

  const audioTracks = stream.getAudioTracks();
  if (audioTracks.length === 0) {
    log("Nemám audio track, není co ztlumit.");
    return;
  }

  isMuted = !isMuted;
  audioTracks.forEach(t => (t.enabled = !isMuted));

  el("btnMute").textContent = isMuted ? "Odtlumit mic" : "Ztlumit mic";
  log(isMuted ? "Mikrofon ztlumen." : "Mikrofon zapnut.");

  // update na server (pokud publish běží)
  if (isPublishing && ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: "set_muted", muted: isMuted }));
  }
}

function connectWs() {
  const url = `wss://${location.host}/ws`;
  ws = new WebSocket(url);

  setWsState("connecting...");
  ws.onopen = () => {
    setWsState("connected");
    log(`WS připojeno: ${url}`);
    el("btnPublishStart").disabled = !canPublish();
  };

  ws.onmessage = (ev) => {
    let data = ev.data;
    log(`WS <= ${data}`);
    try {
      const msg = JSON.parse(data);
      if (msg.type === "publish_ok") {
        presenterId = msg.id;
        isPublishing = true;
        el("btnPublishStart").disabled = true;
        el("btnPublishStop").disabled = false;
        setStatus(`publishing(${presenterId})`, "primary");
      }
      if (msg.type === "publish_stopped") {
        presenterId = null;
        isPublishing = false;
        el("btnPublishStart").disabled = !canPublish();
        el("btnPublishStop").disabled = true;
        setStatus("preview", "success");
      }
      if (msg.type === "publish_error") {
        alert(msg.detail || "Publish error");
        el("btnPublishStart").disabled = !canPublish();
        el("btnPublishStop").disabled = true;
        setStatus("preview", "success");
      }
    } catch (_) {}
  };

  ws.onclose = () => {
    setWsState("disconnected");
    log("WS odpojeno.");
    el("btnPublishStart").disabled = true;
    el("btnPublishStop").disabled = true;
  };

  ws.onerror = () => {
    log("WS chyba (detail v konzoli prohlížeče).");
  };
}

function publishStart() {
  if (!canPublish()) {
    alert("Musíš mít zapnutý náhled, vyplnit jméno i klíč a WS musí být connected.");
    return;
  }

  const msg = {
    type: "publish_start",
    name: el("name").value.trim(),
    key: el("key").value.trim(),
    muted: isMuted,
    ts: Date.now(),
  };

  ws.send(JSON.stringify(msg));
  log(`WS => ${JSON.stringify(msg)}`);
}

function publishStop() {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;

  ws.send(JSON.stringify({ type: "publish_stop", ts: Date.now() }));
  log(`WS => {"type":"publish_stop"}`);
}

window.addEventListener("DOMContentLoaded", () => {
  connectWs();

  el("btnPreview").addEventListener("click", startPreview);
  el("btnStop").addEventListener("click", stopAll);
  el("btnMute").addEventListener("click", toggleMute);

  el("btnPublishStart").addEventListener("click", publishStart);
  el("btnPublishStop").addEventListener("click", publishStop);

  const onInput = () => {
    el("btnPublishStart").disabled = !canPublish() || isPublishing;
  };
  el("name").addEventListener("input", onInput);
  el("key").addEventListener("input", onInput);

  setStatus("idle", "secondary");
  log("Stránka načtena.");
});
